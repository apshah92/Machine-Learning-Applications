import sys
import math
import random

from sklearn.model_selection import cross_val_score
from sklearn import svm
# dot_product function

def dot_product(w,x):
    cols=len(w)
    dp=0
    for j in range(cols):
        dp+=w[j]*x[j]
    return dp

#####reading from data file and label file.

def getdata():
    #datafile=sys.argv[1]
    f=open(datafile,'r')
    data=[]    
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))                
        data.append(l2)
        l=f.readline()

    rows=len(data)
    cols=len(data[0])
    f.close()
    return data

def getlabels():
    #trainlabelfile=sys.argv[2]
    f=open(trainlabelfile,'r')
    trainlabels={}
    i=0
    l=f.readline()
    while(l!=''):
        a=l.split()
        trainlabels[int(a[1])]=int(a[0])
        l=f.readline()
    f.close()
    return trainlabels

def gettestdata():
    testdatafile=sys.argv[3]
    f=open(testdatafile,'r')
    testdata=[]
    
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))                
        testdata.append(l2)
        l=f.readline()

    rows=len(testdata)
    cols=len(testdata[0])
    f.close()
    return testdata
    

def compute(data,labels,k):
    rows=len(data)
    cols=len(data[0])
    
    Z=[]
    Zprime=[]

    clf=svm.LinearSVC(C=0.01)
    
    for j in range(k):    
        #initialize w
        w=[0]*cols
        for j in range(cols):
            w[j]=round(random.uniform(-1,1),2)

        Zcol=[]
                
        for datapoint in data:
            dp_data=dot_product(w,datapoint)
            if dp_data<=0:
                Zcol.append(0)
            else:
                Zcol.append(1)
        Z.append(Zcol)
    Z=list(zip(*Z))

##      Zprimecol=[]
##        for datapoint in testdata:
##            dp_testdata=dot_product(w,datapoint)
##            if dp<=0:
##                Zprimecol.append(0)
##            else:
##                Zprimecol.append(1)
##        Zprime.append(Zprimecol)

    datascores=cross_val_score(clf,data,list(labels.values()),cv=10)
    dataerror=round(1-(sum(datascores)/len(datascores)),2)
    print('error on original data=',dataerror,' ')

    Zscores=cross_val_score(clf,Z,list(labels.values()),cv=10)
    Zerror=round(1-(sum(Zscores)/len(Zscores)),2)
    print('error on new feature data=',Zerror)

##    with open('Errors on Datasets.txt','a') as outfile:
##        outfile.write('For k='+str(k)+' error on original dataset='+str(dataerror)+' error on new feature data='+str(Zerror)+'\n')

    return (clf,Z)
    
        

    

def predict(clf,newfeaturedata,labels,testdata):
    clf.fit(newfeaturedata,list(labels.values()))

    Zprime=[]
    for j in range(k):    
        #initialize w
        w=[0]*cols
        for j in range(cols):
            w[j]=round(random.uniform(-1,1),2)

        Zprimecol=[]
                
        for datapoint in data:
            dp_data=dot_product(w,datapoint)
            if dp_data<=0:
                Zprimecol.append(0)
            else:
                Zprimecol.append(1)
        Zprime.append(Zcol)
    Zprime=list(zip(*Zprime))

    test_predictions=clf.predict(Zprime)
    print('predictions on new test data:',test_predictions)
    
    

    


if __name__=='__main__':
    data=getdata()
    labels=getlabels()
    
    k=2000
    results=compute(data,labels,k)
##    while k<=10000:
##        results=compute(data,labels,k)
##        k=k*10

    clf=results[0]
    newdata=results[1]
    if len(sys.argv)==4:
        testdata=gettestdata()
        predict(clf,newdata,labels,testdata)



    

    
    


        
        




        

        
        
        
    
