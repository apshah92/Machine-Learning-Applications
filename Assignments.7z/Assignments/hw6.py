import sys
import random

def getdata():
    #datafile=sys.argv[1]
    f=open('datafile6.txt','r')
    data=[]
    i=0
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))
        data.append(l2)
        l=f.readline()

    rows=len(data)
    cols=len(data[0])
    f.close()
    return data

def getlabels():
    #trainlabelfile=sys.argv[2]
    f=open('trainlabelfile6.txt','r')
    trainlabels={}
    i=0
    l=f.readline()
    while(l!=''):
        a=l.split()
        trainlabels[int(a[1])]=int(a[0])
        if trainlabels[int(a[1])]==0:             
            trainlabels[int(a[1])]=-1
        l=f.readline()
    f.close()
    return trainlabels

def calc_gini(data,row,col,currsplit,data_label):
    lsize=row+1
    rsize=len(data)-lsize
    lp=0
    rp=0
    rows=len(data)
    for datapoint in data:
        if (datapoint[col]<=currsplit) and (datapoint in data_label[-1]):
            lp+=1    
        elif (datapoint[col]>=currsplit) and (datapoint in data_label[-1]):
            rp+=1
    gini_index=((lsize/rows)*(lp/lsize)*(1 - lp/lsize)) + ((rsize/rows)*(rp/rsize)*(1 - rp/rsize))
    return gini_index

def decision_stump(data,labels):
    data_label={}
    col_split={}
    for i in range(len(data)):
        if labels[i] not in data_label.keys():
            data_label[labels[i]]=[data[i]]
        else:
            data_label[labels[i]].append(data[i])
    for col in range(len(data[0])):
                     data=sorted(data,key=lambda x:x[col])
                     ginies=[]                  
                     for row in range(len(data)-1):
                         if data[row][col]!=data[row+1][col]:           ##if both datapoints have same coordinate,its meaningless to split..
                                                                        ##by extension all points can have same coordinate value.
                                                                        ##for example:(0,0),(1,0),(2,0),(3,0) in this case no sense in calculating split for y values.                                                     
                             s=(data[row][col]+data[row+1][col])/2
                             gini_index=calc_gini(data,row,col,s,data_label)
                             ginies.append([s,gini_index])
                     if ginies!=[]:                             ## ginies would be empty in case of where all points have same value for particular feature.as above
                         ginies=sorted(ginies,key=lambda x:x[1])
                         col_split[col]=ginies[0]
                     
    k=None
    split=None
    best_gini=10000
    for j in col_split:
                     if col_split[j][-1]<best_gini:
                         k=j
                         split=col_split[k][0]
                         best_gini=col_split[j][-1]

    return [k,split]



def getBootStrapData(traindata,labels):
    rows=len(traindata)
    cols=len(traindata[0])
##    randomcols=[]
    col_numbers=[i for  i in range(cols)]
##    if cols<3:
##        print('number of columns must be greater than 3')
##        return
##    else:
##        randomcols=random.sample(range(cols-1),cols//3)    #generate 1/3 distincnt random numbers of column numbers
    bsdata=[]
    for i in range(rows):
        randomrow=random.randint(0,rows-1)
        bsrow=[]
        for j in col_numbers:
            bsrow.append(traindata[randomrow][j])
        bsdata.append(bsrow)
    return (bsdata,col_numbers)              #random cols selected here must be used only for tesdata comparison in prediction()...so randomcols is returned
    
    
    
def getClass(bestcol,split,bsdata,labels):
    leftnegative=0
    leftpositive=0    
    classSides={'left':None,'right':None}
    
    for i,datapoint in enumerate(bsdata):
        if datapoint[bestcol]<split:
            if labels[i]==-1:
                leftnegative+=1
            else:
                leftpositive+=1
        
    if leftnegative>=leftpositive:
        classSides['left']=-1
        classSides['right']=1
    else:
        classSides['left']=1
        classSides['right']=-1
        
    return classSides    
        
                
            
def predict(data,labels):
    traindata=data[:len(labels)]
    testdata=[]
    predictlabels=[]
    for i in range(len(data)):
        if i not in labels.keys():
            testdata.append(data[i])
            
    
    predictions=[[]]*len(testdata)
    
    for k in range(100):
        bootstrapdata_cols=getBootStrapData(traindata,labels)
        print('bsdata:',bootstrapdata_cols[0])
        stump=decision_stump(bootstrapdata_cols[0],labels)            
        print('stump:',stump)
        if stump!=[None,None]:
            splitcol=bootstrapdata_cols[1][stump[0]]
            splitval=stump[1]
            classValues=getClass(splitcol,splitval,bootstrapdata_cols[0],labels)
            for j in range(len(testdata)):
                if testdata[j][splitcol]>=splitval:
                    predictions[j].append(classValues['right'])
                else:
                    predictions[j].append(classValues['left'])
    #print('all the predictions:',predictions)
##    vote={-1:0,1:0}
##    for p in predictions:
##        if p==-1:
##            vote[-1]+=1
##        else:
##            vote[1]+=1
##    print('testdata:',testdata[j],'vote:',vote)
##    if vote[-1]>vote[1]:
##        predictlabels.append(-1)
##    else:
##        predictlabels.append(1)
    for p in predictions:
        if sum(p)>=0:
            predictlabels.append(1)
        else:
            predictlabels.append(-1)
    return predictlabels
            
        
            


if __name__=='__main__':
    data=getdata()
    labels=getlabels()
    print('data:',data[:len(labels)])
    print('\n\nlabels:',labels)
    print('\n\ntestdata:',data[len(labels):])
    predcitedlabels=predict(data,labels)
    
    print('\n\npredictedlabels:',predcitedlabels)
    
    
    
        
        
    

