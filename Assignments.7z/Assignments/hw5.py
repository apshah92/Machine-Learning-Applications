import sys
import math
import random

#####reading from data file and label file.

def getdata():
    #datafile=sys.argv[1]
    f=open('datafile6.txt','r')
    data=[]
    i=0
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))
        data.append(l2)
        l=f.readline()

    rows=len(data)
    cols=len(data[0])
    f.close()
    return data

def getlabels():
    #trainlabelfile=sys.argv[2]
    f=open('trainlabelfile6.txt','r')
    trainlabels={}
    i=0
    l=f.readline()
    while(l!=''):
        a=l.split()
        trainlabels[int(a[1])]=int(a[0])
        if trainlabels[int(a[1])]==0:             
            trainlabels[int(a[1])]=-1
        l=f.readline()
    f.close()
    return trainlabels

def calc_gini(data,row,col,currsplit,data_label):
    lsize=row+1
    rsize=len(data)-lsize
    lp=0
    rp=0
    rows=len(data)
    for datapoint in data:
        if (datapoint[col]<=currsplit) and (datapoint in data_label[-1]):
            lp+=1    
        elif (datapoint[col]>=currsplit) and (datapoint in data_label[-1]):
            rp+=1
    gini_index=((lsize/rows)*(lp/lsize)*(1 - lp/lsize)) + ((rsize/rows)*(rp/rsize)*(1 - rp/rsize))
    return gini_index

def decision_stump(data,labels):
    data_label={}
    col_split={}
    for i in range(len(data)):
        if labels[i] not in data_label.keys():
            data_label[labels[i]]=[data[i]]
        else:
            data_label[labels[i]].append(data[i])
    for col in range(len(data[0])):
                     data=sorted(data,key=lambda x:x[col])
                     ginies=[]                  
                     for row in range(len(data)-1):
                         if data[row][col]!=data[row+1][col]:           ##if both datapoints have same coordinate,its meaningless to split..
                                                                        ##by extension all points can have same coordinate value.
                                                                        ##for example:(0,0),(1,0),(2,0),(3,0) in this case no sense in calculating split for y values.                                                     
                             s=(data[row][col]+data[row+1][col])/2
                             gini_index=calc_gini(data,row,col,s,data_label)
                             ginies.append([s,gini_index])
                     if ginies!=[]:                             ## ginies would be empty in case of where all points have same value for particular feature.as above
                         ginies=sorted(ginies,key=lambda x:x[1])
                         col_split[col]=ginies[0]
                     
    k=None
    split=None
    best_gini=10000
    for j in col_split:
                     if col_split[j][-1]<best_gini:
                         k=j
                         split=col_split[k][0]
                         best_gini=col_split[j][-1]

    return [k,split]

if __name__=='__main__':
                     data=getdata()
                     labels=getlabels()
                     traindata=data[:len(labels)]
                     stump=decision_stump(traindata,labels)
                     print('data:',data,'\n\ntrue labels:',labels)
                     print('\nk=',stump[0],'\ns=',stump[1])
                     
                     
                     
                     
                         
                     
                     
                     
                     
                     
                     
    
    
    

