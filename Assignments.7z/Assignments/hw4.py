import sys
import math
import random

# dot_product function

def dot_product(w,x):
    cols=len(w)
    dp=0
    for j in range(cols):
        dp+=w[j]*x[j]
    return dp

#####reading from data file and label file.

def getdata():
    datafile=sys.argv[1]
    f=open(datafile,'r')
    data=[]
    i=0
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))
        l2.append(1)        
        data.append(l2)
        l=f.readline()

    rows=len(data)
    cols=len(data[0])
    f.close()
    return data

def getlabels():
    trainlabelfile=sys.argv[2]
    f=open(trainlabelfile,'r')
    trainlabels={}
    i=0
    l=f.readline()
    while(l!=''):
        a=l.split()
        trainlabels[int(a[1])]=int(a[0])
    ##    if trainlabels[int(a[1])]==0:             # do not convert label 0 to -1 for logistic regression gradient descent
    ##        trainlabels[int(a[1])]=-1
        l=f.readline()
    f.close()
    return trainlabels




def compute(data,trainlabels):
    rows=len(data)
    cols=len(data[0])
    
    #initialize w
    w=[0]*cols
    for j in range(cols):
        w[j]=0.02*random.random()-0.01


    #gradient descent iteration
    eta=0.01
    preverror=0

    for k in range(100000):    
        dellf=[0]*cols
        for i in range(rows):
            if i < len(trainlabels):
                dp=dot_product(w,data[i])
                for j in range(cols):
                    dellf[j]+=(trainlabels[i]-1/(1+math.exp((-1)*dp)))*data[i][j]       #logistic regression gradient descent

                w[-1]=w[-1]+eta*(trainlabels[i]-1/(1+math.exp((-1)*dp)))
        #update
                    
        for j in range(cols-1):
            w[j]=w[j]+eta*dellf[j]

        

        

        #compute error
        currerror=0
        for i in range(rows):
            if i < len(trainlabels):
                currerror+=(trainlabels[i]-dot_product(w,data[i]))**2
        
        if abs(preverror-currerror)<=0.0000001:    #use absolute value only
            break
        preverror=currerror
    return w
    
def distance_origin(w):
    cols=len(w)
    normw=0
    for j in range(cols-1):
        normw+=w[j]**2
        

    print()
    normw=math.sqrt(normw)
    print('||w||=',normw,'\n')
    
    d_origin=abs(w[-1]/normw)           #use absolute value as w0 could be -ve.
    print('distance to origin=',d_origin,'\n')


def test_pridiction(data,trainlabels):
    
    rows=len(data)
    
    #Prediction for test data at the end of datafile
    for i in range(rows):
        if i not in trainlabels.keys():
            print('testdata prediction:')
            dp=dot_product(w,data[i])
            if(dp>0):
                print('point:',i,' class:1')
            else:
                print('point:',i,' class:0')


if __name__=='__main__':
    data=getdata()
    labels=getlabels()

    print('data=')
    for i in range(len(data)):
        for j in range(len(data[i])-1):
            print(data[i][j],' ',end='')
        print()
        

    print('labels=')
    for i in range(len(labels)):
        print(labels[i])


    w=compute(data,labels)
    print('\nw=',)
    for i in range(len(w)-1):
        print(w[i],' ',end=' ')
    #print('\nw0=',w[-1])
    
    d_origin=distance_origin(w)
    test_pridiction(data,labels)
    
        
    

