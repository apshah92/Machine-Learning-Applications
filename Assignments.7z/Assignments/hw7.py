import sys
import math

def getdata():
    #datafile=sys.argv[1]
    f=open('datafile7.txt','r')
    data=[]
    i=0
    l=f.readline()

    while(l!=''):
        a=l.split()
        l2=[]
        for j in range(len(a)):
            l2.append(float(a[j]))
        data.append(l2)
        l=f.readline()

    rows=len(data)
    cols=len(data[0])
    f.close()
    return data

def distanceToMean(datapoint,mean):
    cols=len(datapoint)
    distance=0
    for i in range(cols):
        distance+=(datapoint[i]-mean[i])**2
    return math.sqrt(distance)

def formClusters(data):
    #k=int(sys.argv[2])
    k=4
    cols=len(data[0])
    labels=[]
    for i in range(len(data)):
        labels.append(i%k)
    prevobj=10000  
    currobj=0
    eta=0.01

    while(abs(prevobj-currobj)>eta):
        m=[]                  #m-mean list stores mean of each cluster..each element of m has cols features as data
        for i in range(k):
            m.append([0]*cols)
        clusterLength=[0]*k             #keeps track of number of data in each cluster..used in calculation of mean for division e.g. m=[[sum(cluster[0][data])/len(cluster[0]),...]]
        for i in range(len(data)):
            for j in range(cols):
                m[labels[i]][j]+=data[i][j]  #summing up all data grouped by cluster
            clusterLength[labels[i]]+=1
        for i in range(len(m)):
            for j in range(cols):
                if clusterLength[i]!=0:
                    m[i][j]=m[i][j]/clusterLength[i]
        for i in range(len(data)):
            currentDistance=10000
            newCluster=None
            for index,clustMean in enumerate(m):
                d=distanceToMean(data[i],clustMean)
                if d<currentDistance:
                    currentDistance=d
                    newCluster=index
            labels[i]=newCluster
            
        prevobj=currobj
        currobj=0
        for clustMean in m:
            for i in range(len(data)):
                for j in range(cols):
                    currobj+=(data[i][j]-clustMean[j])**2
    return labels

def printLabels(labels):
    for dataindex,label in enumerate(labels):
        print(dataindex,' ',label)

if __name__=='__main__':
    data=getdata()
    print(data)
    labels=formClusters(data)
    printLabels(labels)
    
            
            
                
            
        
            
            
        
    
    
    
