import sys
import math
import random

# dot_product function

def dot_product(w,x):
    dp=0
    for j in range(cols):
        dp+=w[j]*x[j]
    return dp

#####reading from data file and label file.

#datafile=sys.argv[1]
f=open('datafile2.txt','r')
data=[]
i=0
l=f.readline()

while(l!=''):
    a=l.split()
    l2=[]
    for j in range(len(a)):
        l2.append(float(a[j]))
    l2.append(1)        
    data.append(l2)
    l=f.readline()

rows=len(data)
cols=len(data[0])
f.close()


#trainlabelfile=sys.argv[2]
f=open('trainlabelfile2.txt','r')
trainlabels={}
i=0
l=f.readline()
while(l!=''):
    a=l.split()
    trainlabels[int(a[1])]=int(a[0])
    if trainlabels[int(a[1])]==0:
        trainlabels[int(a[1])]=-1
    l=f.readline()
f.close()

print(trainlabels)
#####

#initialize w

w=[0]*cols
for j in range(cols):
    w[j]=0.02*random.random()-0.01

#gradient descent iteration

eta=0.001
preverror=0

for k in range(100000):    
    dellf=[0]*cols
    for i in range(rows):
        if i < len(trainlabels):
            dp=dot_product(w,data[i])
            for j in range(cols):
                dellf[j]+=(trainlabels[i]-dp)*data[i][j]

    #update
                
    for j in range(cols):
        w[j]=w[j]+eta*dellf[j]

    

    #compute error
    currerror=0
    for i in range(rows):
        if i < len(trainlabels):
            currerror+=(trainlabels[i]-dot_product(w,data[i]))**2
    
    if abs(preverror-currerror)<=0.001:    #use absolute value only
        break
    preverror=currerror
print('error = ',currerror)
print('w=',w)
    
#print('error = ',error)
normw=0
for j in range(cols-1):
    normw+=w[j]**2
    print(w[j])

print()
normw=math.sqrt(normw)
print('||w||=',normw,'\n')
print('w[-1]=',w[-1],' w[len(w)-1]=',w[len(w)-1])
d_origin=abs(w[-1]/normw)           #use absolute value as w0 could be -ve.
print('distance to origin=',d_origin,'\n')

#Prediction

for i in range(rows):
    if i not in trainlabels.keys():
        dp=dot_product(w,data[i])
        if(dp>0):
            print('point:',i,' class:1')
        else:
            print('point:',i,' class:0')
        
    

