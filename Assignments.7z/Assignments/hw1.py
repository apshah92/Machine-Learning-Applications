import sys
import math

datafile=sys.argv[1]
f=open(datafile,'r')
data=[]
i=0
l=f.readline()

while(l!=''):
    a=l.split()
    l2=[]
    for j in range(len(a)):
        l2.append(float(a[j]))
    data.append(l2)
    l=f.readline()

rows=len(data)
cols=len(data[0])


#Read label from file

trainlabelfile=sys.argv[2]
f=open(trainlabelfile,'r')
trainlabels={}
i=0
l=f.readline()
while(l!=''):
    a=l.split()
    trainlabels[int(a[1])]=int(a[0])
    l=f.readline()

print('data:')    
for i in data:
    print(i)
print('\nclass labels:')
for i in trainlabels.keys():
    print(trainlabels[i],i)

m0=[]
m1=[]

for i in range(cols):
    m0.append(1)
    m1.append(1)

n0=0
n1=0

for i in range(rows):
    if(trainlabels.get(i)!=None and trainlabels[i]==0):
        n0+=1
        for j in range(cols):
            m0[j] +=data[i][j]
    if(trainlabels.get(i)!=None and trainlabels[i]==1):
        n1+=1
        for j in range(cols):
            m1[j]+=data[i][j]
            
for j in range(cols):
    m0[j]/=n0
    m1[j]/=n1

print('\nmean for class 0:',m0)
print('mean for class 1:',m1)


sd0=[0,0]
sd1=[0,0]
for i in range(rows):    
    if(trainlabels.get(i)!=None and trainlabels[i]==0):
        for j in range(cols):
            sd0[j]+=(data[i][j]-m0[j])**2
    if(trainlabels.get(i)!=None and trainlabels[i]==1):
        for j in range(cols):
            sd1[j]+=(data[i][j]-m1[j])**2

for j in range(cols):
    sd0[j]=math.sqrt(sd0[j]/n0)
    sd1[j]=math.sqrt(sd1[j]/n1)
    
print('\nstandard deviation for class 0:',sd0)
print('standard deviation for class 1:',sd1)


#nearest means

##f=open('testdata.txt','r')
##testdata=[]
##i=0
##l=f.readline()
##
##while(l!=''):
##    a=l.split()
##    l2=[]
##    for j in range(len(a)):
##        l2.append(float(a[j]))
##    testdata.append(l2)
##    l=f.readline()
##
##classlabel=[0]*len(testdata)
##dist=[0,0]
##
##for i in range(len(testdata)):
##    dist[0]=math.sqrt((m0[0]-testdata[i][0])**2 + (m0[1]-testdata[i][1])**2 )
##    dist[1]=math.sqrt((m1[0]-testdata[i][0])**2 + (m1[1]-testdata[i][1])**2 )
##    classlabel[i]=dist.index(min(dist))
##
##for i,label in enumerate(classlabel):
##    print('point ',i,':',label)



#Naive bayes


testdata=data[len(trainlabels):]
print('\ntestdata:',testdata,'\n')
classlabel=[0]*len(testdata)
dist=[0,0]

for i in range(len(testdata)):
    dist[0]= ((m0[0]-testdata[i][0])/sd0[0])**2 + ((m0[1]-testdata[i][1])/sd0[1])**2
    dist[1]= ((m1[0]-testdata[i][0])/sd1[0])**2 + ((m1[1]-testdata[i][1])/sd1[1])**2
    classlabel[i]=dist.index(min(dist))

print('predicted labels:')
for i,label in enumerate(classlabel):
    print('point ',i+len(trainlabels),':',label)        
            





    
    
    
