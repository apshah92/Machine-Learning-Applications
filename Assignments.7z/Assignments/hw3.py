import sys
import math
import random

# dot_product function

def dot_product(w,x):
    dp=0
    for j in range(cols):
        dp+=w[j]*x[j]
    return dp

#####reading from data file and label file.

datafile=sys.argv[1]
f=open(datafile,'r')
data=[]
i=0
l=f.readline()

while(l!=''):
    a=l.split()
    l2=[]
    for j in range(len(a)):
        l2.append(float(a[j]))
    l2.append(1)        
    data.append(l2)
    l=f.readline()

rows=len(data)
cols=len(data[0])
f.close()


trainlabelfile=sys.argv[2]
f=open(trainlabelfile,'r')
trainlabels={}
i=0
l=f.readline()
while(l!=''):
    a=l.split()
    trainlabels[int(a[1])]=int(a[0])
    if trainlabels[int(a[1])]==0:
        trainlabels[int(a[1])]=-1
    l=f.readline()
f.close()

print(trainlabels)
#####

#initialize w

w=[0]*cols
for j in range(cols):
    w[j]=0.02*random.random()-0.01

#gradient descent iteration

iteration=0
eta=0.001
preverror=0

while iteration<100000:    
    dellf=[0]*cols
    for i in range(rows):
        if i < len(trainlabels):
            dp=dot_product(w,data[i])
            sub_grad= trainlabels[i]*dp
            for j in range(cols):
                if sub_grad<1:
                    dellf[j]+=(data[i][j]*trainlabels[i])
                else:
                    dellf[j]+=0

    #update
                
    for j in range(cols):
        w[j]=w[j]+eta*dellf[j]

    

    #compute error
    currerror=0
    for i in range(rows):
        if i < len(trainlabels):
            currerror+=(trainlabels[i]-dot_product(w,data[i]))**2
    
    if abs(preverror-currerror)<=0.000000001:
        break
    preverror=currerror
    iteration+=1
    
print('w=',w)
print('\nw0=',w[-1])

#print('error = ',error)
normw=0
for j in range(cols-1):
    normw+=w[j]**2

print()
normw=math.sqrt(normw)

d_origin=abs(w[len(w)-1]/normw)
print('distance to origin=',d_origin,'\n')

#Prediction

for i in range(rows):
    if i not in trainlabels.keys():
        dp=dot_product(w,data[i])
        if(dp>0):
            print('point:',i,' class:1')
        else:
            print('point:',i,' class:0')
        
    

